
const { defineConfig } = require('cypress');

module.exports = defineConfig({
  e2e: {
    baseUrl: 'http://localhost:5173', // Adjust based on your Vite or Replit dev server
    setupNodeEvents(on, config) {
      // implement node event listeners here if needed
    },
  },
  env: {
    email: 'user@example.com',
    password: 'password123',
  },
});
